import "./App.css";
import { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Screens
import HomeScreen from "./screens/HomeScreen";
import ProductScreen from "./screens/ProductScreen";
import CartScreen from "./screens/CartScreen";
// import LoginForm from "./components/Login";

// components
import Navbar from "./components/Navbar";
// import Backdrop from "./components/Backdrop";
import SideDrawer from "./components/SideDrawer";
// import { useParams } from "react-router-dom";

function App() {
  const [sideToggle, setSideToggle] = useState(false);

  // console.log(process.env.REACT_APP_API_URL);
  // const { id } = useParams();
  return (
    <>
      <Router>
        {/* <Backdrop show={sideToggle} click={() => setSideToggle(false)} /> */}
        {sideToggle && (
          <SideDrawer show={sideToggle} click={() => setSideToggle(false)} />
        )}
        <Navbar click={() => setSideToggle(!sideToggle)} />;
        <main>
          <Routes>
            <Route exact path="/" element={<HomeScreen />} />
            {/* <Route exact path="/products/login" element={<LoginForm />} /> */}
            <Route exact path="/products/:id" element={<ProductScreen />} />
            <Route exact path="/products/cart" element={<CartScreen />} />
          </Routes>
        </main>
      </Router>
    </>
  );
}

export default App;
