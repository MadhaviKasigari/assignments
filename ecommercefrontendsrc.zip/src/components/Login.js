import React, { useState } from "react";
import axios from "axios"; // Import axios for making HTTP requests
import "./Login.css";

export default function LoginForm() {
  const [values, setValues] = useState({
    firstName: "",
    lastName: "",
    email: "",
  });

  const handleInputChange = (event) => {
    event.preventDefault();

    const { name, value } = event.target;
    setValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };

  const [submitted, setSubmitted] = useState(false);
  const [valid, setValid] = useState(false);
  const [error, setError] = useState(null); // State to hold login errors

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null); // Reset error state

    try {
      const response = await axios.post("/api/login", values); // Assuming backend endpoint is /api/login
      if (response.data.success) {
        setValid(true);
        setSubmitted(true);
      } else {
        setError(response.data.message); // Set error message from backend response
      }
    } catch (error) {
      setError("An error occurred. Please try again."); // Handle network errors
    }
  };

  return (
    <div className="form-container">
      <form className="register-form" onSubmit={handleSubmit}>
        {submitted && valid && (
          <div className="success-message">
            <h3>
              {" "}
              Welcome {values.firstName} {values.lastName}{" "}
            </h3>
            <div>Your Login was successful!</div>
          </div>
        )}
        {error && (
          <div className="error-message">
            <span>{error}</span>
          </div>
        )}
        {!valid && (
          <input
            className="form-field"
            type="text"
            placeholder="First Name"
            name="firstName"
            value={values.firstName}
            onChange={handleInputChange}
          />
        )}
        {!valid && (
          <input
            className="form-field"
            type="text"
            placeholder="Last Name"
            name="lastName"
            value={values.lastName}
            onChange={handleInputChange}
          />
        )}
        {!valid && (
          <input
            className="form-field"
            type="text"
            placeholder="Email "
            name="email"
            value={values.email}
            onChange={handleInputChange}
          />
        )}
        {!valid && (
          <button className="form-field" type="submit">
            Login
          </button>
        )}
      </form>
    </div>
  );
}
